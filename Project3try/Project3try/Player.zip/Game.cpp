#include "Game.h"
#include "CConsole.h"
#include "Maze.h"
#include "Player.h"

Game::Game(int delay){
	console = new CConsole(60,25);
	maze = new Maze(console);
	isGameOver = maze -> loadMaze("MAZE" + to_string(player -> getLevel()) + ".txt");
	player = new Player(maze -> getPlayerStartX(), maze ->getPlayerStartY(), maze, console, 3, 0, 0);
	delayAmount = delay;
	
}

Game::~Game(){
	delete console;
	delete maze;
	delete player;
}

void Game::run(){
	startLevel();

	printMessage();

	while(player -> getNumLivesLeft() != 0 || isGameOver == true){
		console -> delay(delayAmount);
		if(console -> getInput(input))
			player ->changeDirection(input);
		player -> move();
		if(maze -> clearMazePosition(player ->getX() , player ->getY())){
			console -> gotoXY(27 , 23);
			console -> printInt(player -> getScore());
		if(maze -> done())
			endLevel();
		}
	}
	//need to handle if beat all of the levels
}

void Game::printMessage(){
	console -> printStringClearLine(0 , 24 , "");
	console -> gotoXY(0 , 23);
	console -> printString("Lives: ");
	console -> printInt(player -> getNumLivesLeft());
	console -> gotoXY(9, 23);
	console -> printString("Levels: ");
	console -> printInt(player -> getLevel());
	console -> gotoXY(19, 23);
	console -> printString("Score: ");
	console -> printInt(player -> getScore());
}
	
void Game::startLevel(){
	maze -> display();
	maze -> displayActors();

	console -> gotoXY(0, 24);
	console -> printString("Press Enter to Start Game");
	console -> waitForEnter();

}

void Game::endLevel(){
	isGameOver = maze -> loadMaze("MAZE" + to_string(player -> getLevel()));
	player -> resetDirection();
	console -> gotoXY(0 , 24);
	console -> printString("You beat the level!");
	startLevel();
	//load new maze
	//reset direction actors
	//say completed level and hit enter
	//wait for enter
}