#include "Inky.h"

void Inky::move(){
	moveRandom();
}
