#include "Actor.h"
#include "Player.h"

#ifndef MONSTER_H
#define MONSTER_H

class Monster:public Actor{
public:
	Monster(int x, int y,Maze * m, CConsole * c, Player * p):Actor(x, y, m, c){
	isNorm = true;
	isVuln = false;
	isGoHome = false;
	}

	void returnToHome();//monster takes shortest route home from their position when eaten
	//need to make sure nothing messes with it when its on its path home
	//all monsters are a $ when they return
	virtual bool isOnPlayer() = 0;//will return true monster is on Player
	//all will have to check every tick/move they make to see if they are on Player


	//these are passed down from Actor
	virtual void move() = 0; //passing down again because each monster will move differently
	//print what was in the space before Monster moved there after they leave;
	//don't eat pellets or reput them back on map.
	void resetDirection(); //resets all monsters at home when level completed or player dies
	virtual char getDisplayChar() = 0;//will return each specific char for each monster during certain state
	virtual void setNormal();//will set everything back to normal - colors, chars, call specific movement method
	//used when Monsters go back home after being eaten or after counter for vulnerability counter is 0
	virtual void setVulnerable();//will set everything to vulnerable - colors, chars, call specific movement method
	//used when player eats a power pellet



protected:
	bool isNorm, isVuln, isGoHome;//used to tell monsters state
	int counter;//will be used for how many ticks it will stay vulnerable
	Player * player;

	void getLevel(); // will get the level player is on so the Monster can know how long to be vulnerable for
	void moveVulnShare();//will move the monster randomly
	//used for Inky's normal and vulnerable state
	//used for Clyde's vulnerable state
	void moveNormShare();//uses the line - of - sight movement
	//used for Clyde's normal state
	//used for Stinky's normal state

};

#endif