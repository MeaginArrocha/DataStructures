#include "Monster.h"

class Inky:public Monster{
public:
	Inky(int x, int y,Maze * m, CConsole * c, Player * p):Monster(x, y, m, c, p){}	

	//passed down from Monster
	void move();
	//will use the ICVulnMove because he uses random for normal and vulnerable
	char getDisplayChar();
	void setNormal();
	void setVulnerable();
	bool isOnPlayer();

private:

};